Notes:

Get Data and Export depend on the text in the Query field. If the Query is empty/null or if the Query
has not been collected before, I send the user a message telling them to click Get Data first.

If Query is empty when Read/Display is clicked, tweets from the first name in the collection list are displayed.
If Query does not match any of the collection names when Read/Display is clicked, I send the user a message telling them to click Get Data first.



To run, use "npm install" then "npm start".

