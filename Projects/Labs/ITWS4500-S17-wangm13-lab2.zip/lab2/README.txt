For this lab, I used a Heroic Bootstrap template (https://startbootstrap.com/template-overviews/heroic-features/), 
and Weather Icons to display the weather icons (https://erikflowers.github.io/weather-icons/).

At the top of the page, I display today's current temperature, high and low, and additional information which
is swapped every 3 seconds using jQueryUI's drop() transition.

At the bottom of the page, I simply just display the 5-day forecast.

Webfonts for more creativity, yay!

I tried creating the ssl certificate using this tutorial (https://www.sslshopper.com/article-how-to-create-and-install-an-apache-self-signed-certificate.html) but https still doesn't work for some reason.