Individual:
Github: https://github.com/mwang25277/WebScience

Group:
Github: https://github.com/mwang25277/ShowOfHands

Our group will be using GitHub Issues for bugtracking.

http://159.203.84.202:3000/

Username: corey
Password: pass