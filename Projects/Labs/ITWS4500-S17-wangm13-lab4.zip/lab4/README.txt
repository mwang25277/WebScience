I decided to use the Reddit API (https://www.reddit.com/dev/api/) to pull the newest aww posts and display them using Angular and Bootstrap.
The after and count tags are used for pagination.

For media queries, I mainly worked with the iPhone 5 and iPad screen sizes (both portrait and landscape modes).

When resized to iPhone 5 size, the background changes to a light red, the navbar shrinks to 20px, and the pictures are organized into a 1x4 column.

When resized to iPad size, the background changes to a light blue, the navbar shrinks to 30px, and the pictures are organized into a 2x2 grid.
